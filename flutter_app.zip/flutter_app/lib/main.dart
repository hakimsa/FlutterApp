// Flutter code sample for material.BottomNavigationBar.1

// This example shows a [BottomNavigationBar] as it is used within a [Scaffold]
// widget. The [BottomNavigationBar] has three [BottomNavigationBarItem]
// widgets and the [currentIndex] is set to index 0. The selected item is
// amber. The `_onItemTapped` function changes the selected item's index
// and displays a corresponding message in the center of the [Scaffold].
//
// ![A scaffold with a bottom navigation bar containing three bottom navigation
// bar items. The first one is selected.](https://flutter.github.io/assets-for-api-docs/assets/material/bottom_navigation_bar.png)

import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_database/firebase_database.dart';
//import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_app/ListadoAyudas.dart';
import 'package:flutter_app/NavigatorDrw.dart';

import 'Appanalitic.dart';



void main() => runApp(MyApp());

/// This Widget is the main application widget.
class MyApp extends StatelessWidget {
  static const String _title = 'Flutter Code Sample';
  FirebaseAnalytics analytics = FirebaseAnalytics();
  final databaseReference = FirebaseDatabase.instance.reference().child("ayudas");
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: NavigatorDrw(),
     navigatorObservers: [FirebaseAnalyticsObserver(analytics: analytics),
      ],
    );
  }
}

class MyStatefulWidget extends StatefulWidget {
  MyStatefulWidget({Key key}) : super(key: key);

  @override
  _MyStatefulWidgetState createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {

  int _selectedIndex = 0;
  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.bold);

  static const List<Widget> _widgetOptions = <Widget>[

    Center(child:Scaffold(
      backgroundColor: Color.fromARGB(301, 180, 322, 224),
      //body:images.add("assets/background.jpg"),


    ),

    ),



  Center(child:Scaffold(
    backgroundColor: Color.fromARGB(091, 1830, 222, 204),
     bottomSheet: Center(child: Text("HGG"),),
     floatingActionButton: FloatingActionButton(onPressed: null,
     tooltip: "hola",
     child: Text("botona"),
     backgroundColor: Colors.amber,

     ), ) ,
     //body:images.add("assets/background.jpg"),

  ),

    Center(child:Scaffold(
      backgroundColor: Color.fromARGB(200, 300, 222, 204),
      //body:images.add("assets/background.jpg"),



    ),
    ),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),

      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            title: Text('Casa'),



          ),


          BottomNavigationBarItem(
            icon: Icon(Icons.business),
            title: Text('Trabajo'),
            backgroundColor: Colors.green),




          BottomNavigationBarItem(
            icon: Icon(Icons.card_travel),
            title: Text('Como gestionarlo '),
          ),
        ],



        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue[900],
        onTap: _onItemTapped,
      ),
    );
  }
}


class widgt extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Stack(
      children: <Widget>[
        new MyApp2(),

      ],
    );
  }



}
class GradientBack extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Container(

      decoration: new BoxDecoration(gradient: new LinearGradient(colors:[Color.fromARGB (022, 222, 123, 312),
        Color.fromARGB(012, 050, 111, 222)],
          begin: const FractionalOffset(3.0, 5.1),end:const FractionalOffset(8.0, 0.1)),
      ),child: new _ReoredableListDemo(),

    );
  }


}class listItem{
  listItem(this.value,this.checked);
  final String value;
  bool checked;
  void ische(){
    if(checked=true)
      print(value.toString());


  }

}


class _ReoredableListDemo extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _ReoredableListDemoState();
    new _segundaPagina();
  }
}
//lista
class _ReoredableListDemoState extends State<_ReoredableListDemo>{
  bool reversShort=false;
  static final  misItems=<String>[
    "Hakim samouh",
    "roberto",
    "juan",
    "Miguel",
  ].map((item)=> listItem(item,false)).toList();
//constructor de la lista


  void onRender(int oldIndex,int newIndex){
    setState(() {
      if(newIndex >oldIndex){
        newIndex -=1;
      }
      final listItem item=misItems.removeAt(oldIndex);
      misItems.insert(newIndex, item);
    });
  }
  @override
  Widget build(BuildContext context) {
    final appbar=AppBar(
      title: Text("Contactos"),
      automaticallyImplyLeading: false,
      actions: <Widget>[
        IconButton(
          icon :Icon(Icons.contact_mail),
          tooltip: "Contactos",
          onPressed:(){

            Navigator.push(context, _segundaPagina());
          },
        ),
      ],
    );


    final ListTile =misItems.map((item)=>CheckboxListTile(key :Key (item.value),value: item.checked ?? false,
      onChanged: (bool newValue){
        setState(()=> item.checked=newValue);
      },title: Text("${item.value}"),

      isThreeLine: true,
      subtitle: Text("${item.value}"),
      secondary: Icon(Icons.assignment),)
      ,

    ).toList();
    // TODO: implement build
    return Scaffold(
      appBar: appbar,
      body: ReorderableListView(children: ListTile, onReorder: onRender),
    );

  }

}
final  misItems=<String>[
  "Hakim samouh",
  "juan ",
  " Miguel",
  "hakim  samouh samouh ",
  "Hakim",
  "juan",
  "Miguel",
].map((item)=> listItem(item,false)).toList();
final listItem item=misItems.removeAt(6);



class _segundaPagina extends MaterialPageRoute<Null> {

  _segundaPagina()
      :super( builder:(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        appBar: AppBar(title: Text("Detalles del Contacto "), elevation: 2.0,),
        floatingActionButton: FloatingActionButton(
            tooltip: 'Update Text',
            backgroundColor: Colors.lightBlueAccent,
            onPressed: ()=>Navigator.of(context).push(_pageFilter()),
            child: Icon(Icons.search)),
        body: Builder(builder: (BuildContext context)=> Center(child: ListView(children: <Widget>[ListTile(leading: CircleAvatar(child: Text("${item.value.substring(item.value.length-1,item.value.length)}")),
          title: Text("${item.value.toLowerCase()}"),
          onTap: ()=> Navigator.pop(context,'hakimsamou@2kim.net'),),ListTile(leading:CircleAvatar(child: Text("${item.value.substring(item.value.length-1,item.value.length)}")) ,)]
          ,)
          ,)
          ,)

    );
  },
  );
}

class _pageFilter extends MaterialPageRoute<Null> {
  _pageFilter()
      :super(builder: (BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(title: Text("Filter "), elevation: 2.0,),
      floatingActionButton: FloatingActionButton(
          tooltip: 'Update Text',
          backgroundColor: Colors.blue,
          onPressed: () => Navigator.of(context).push(_segundaPagina()),
          child: Icon(Icons.menu)),
      body: Builder(builder: (BuildContext context)=> Center(child: ListView(children: <Widget>[ListTile(leading: CircleAvatar(child: Text("${item.value.substring(item.value.length-1,item.value.length)}")),)]
        ,)
        ,)
        ,)

        
    );
  },
  );
}

class PlaceList1 extends StatelessWidget {
  static final String path = "lib/src/pages/lists/list1.dart";

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("Listado de Ayudas"),
        backgroundColor: Colors.blue,
        elevation: 2,
        actions: <Widget>[
          Container(
            padding: EdgeInsets.all(10),
            child: Icon(Icons.filter_list),
          )
        ],
      ),
      body: Lists(),
    );
  }
}

class Item {
  final String title;
  final String catagory;
  final String place;
  final String ratings;
  final String discount;
  final String image;

  Item(
      {this.title,
        this.catagory,
        this.place,
        this.ratings,
        this.discount,
        this.image});
}

class Lists extends StatelessWidget {
  final List<Item> _data = [
    Item(
        title: 'Gardens By the Bay',
        catagory: "Gardens",
        place: "Singapore",
        ratings: "5.0/80",
        discount: "10 %",
        image: "https://images.pexels.com/photos/672142/pexels-photo-672142.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"),
    Item(
        title: 'Singapore Zoo',
        catagory: "Parks",
        place: "Singapore",
        ratings: "4.5/90",
        discount: null,
        image: "https://images.pexels.com/photos/1736222/pexels-photo-1736222.jpeg?cs=srgb&dl=adult-adventure-backpacker-1736222.jpg&fm=jpg"),
    Item(
        title: 'National Orchid Garden',
        catagory: "Parks",
        place: "Singapore",
        ratings: "4.5/90",
        discount: "12 %",
        image: "https://images.pexels.com/photos/62403/pexels-photo-62403.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"),
    Item(
        title: 'Godabari',
        catagory: "Parks",
        place: "Singapore",
        ratings: "4.5/90",
        discount: "15 %",
        image: "https://images.pexels.com/photos/189296/pexels-photo-189296.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"),
    Item(
        title: 'Rara National Park',
        catagory: "Parks",
        place: "Singapore",
        ratings: "4.5/90",
        discount: "12 %",
        image: "https://images.pexels.com/photos/1319515/pexels-photo-1319515.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: EdgeInsets.all(6),
      itemCount: _data.length,
      itemBuilder: (BuildContext context, int index) {
        Item item = _data[index];
        return Card(
          elevation: 3,
          child: Row(
            children: <Widget>[
              Container(
                height: 125,
                width: 110,
                padding:
                EdgeInsets.only(left: 0, top: 10, bottom: 70, right: 20),
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: NetworkImage(item.image),
                        fit: BoxFit.cover)),
                child:item.discount==null?Container(): Container(
                  color: Colors.blueAccent,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(
                        item.discount,
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.normal),
                      ),
                      Text(
                        "Discount",
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.normal),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      item.title,
                      style: TextStyle(
                          color: Colors.deepOrange,
                          fontWeight: FontWeight.w700,
                          fontSize: 17),
                    ),
                    Text(
                      item.catagory,
                      style: TextStyle(fontSize: 14, color: Colors.black87),
                    ),
                    Text(
                      item.place,
                      style: TextStyle(fontSize: 14, color: Colors.black87),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.star,
                          color: Colors.pink,
                          size: 10,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.pink,
                          size: 18,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.pink,
                          size: 18,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.pink,
                          size: 18,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.pink,
                          size: 18,
                        ),
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        Text(item.ratings, style: TextStyle(
                            fontSize: 13
                        ),),
                        SizedBox(
                          width: 5,
                        ),
                        Text("Ratings", style: TextStyle(fontSize: 13),),
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        );
      },
    );
  }
}

