import 'dart:io';

//import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_app/Appanalitic.dart';
import 'package:flutter_app/ListadoAyudas.dart';
import 'package:flutter_app/MyLogin.dart';
import 'package:flutter_app/image.dart';
import 'package:flutter_app/main.dart';
import 'package:flutter_app/models/animpage.dart';



class NavigatorDrw extends StatelessWidget{
  @override
  Widget build(BuildContext context) {

    final drawerHeader=UserAccountsDrawerHeader(
      accountName:Text('Hola'),
      accountEmail:Text('samouhHakim@gmailcom'    ),
    currentAccountPicture:CircleAvatar(child:FlutterLogo(size:42.0),

        backgroundColor:Colors.white,
    ),otherAccountsPictures: <Widget>[
      CircleAvatar(child: Text('H'),
    backgroundColor: Colors.purpleAccent,),
    CircleAvatar(
    child: Text("S"),
    backgroundColor: Colors.green,

    )
    ],);

    final drawerItems=ListView(
      children: <Widget>[
        drawerHeader,ListTile(
          title: Text("Categorias"),
          onTap: (){
    Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => FirstRoute()
    ),);}),

        ListTile(
        title: Text("Articulo"),
    onTap: () {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => widgt())
    ,);}),
      ListTile(
        title: Text("Login"),
        onTap: (){
    Navigator.push(
    context,
    MaterialPageRoute(builder: (context) =>FirebaseLoginExample())
    ,);}),
    ListTile(
    title: Text("Lista"),
    onTap: () {
    Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => PlaceList1())
    ,);}
    ),
        ListTile(
            title: Text("Animation"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => GradientBack())
                ,);}
        ),
    ]);
    return Scaffold(
        appBar: AppBar(
        backgroundColor: Colors.blueAccent,
      title: Text("GaliciaBebe"),
    ),
    body: Center(
    child: Container(child: new MyStatefulWidget())
    ),
    drawer: Drawer(
    child: drawerItems,
    ),
    );
  }
}



class SecondRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Second Route"),
      ),
      body: Center(
        child:Column(mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,children: <Widget>[
                CircleAvatar(child: Icon(Icons.home,size: 35.0,),
               minRadius: 60,
              backgroundColor: Colors.deepOrange.shade300,),RaisedButton(onPressed: () {
              // Navigate back to first route when tapped.
            },
              child: Text('Go back!'),
              color: Colors.purpleAccent,
              textColor: Colors.white,)
          ],
          )
          ],
        ),



      ),
    );
  }
}


    class FirstRoute extends StatelessWidget {
      final List<Color> tileColors = [
        Colors.green,
        Colors.blue,
        Colors.purple,
        Colors.pink,
        Colors.indigo,
        Colors.lightBlue,
        Colors.amber,
        Colors.deepOrange,
        Colors.red,
        Colors.brown
      ];

      @override
      Widget build(BuildContext context){
        return Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.deepPurple,
              title: Text('Galica Bebe App'),
              elevation: 0,
            ),
            body: Stack(
              children: <Widget>[
                ClipPath(
                //clipper: WaveClipperTwo(),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.deepPurple
                    ),
                    height: 200,
                  ),
                ),
                CustomScrollView(
                  physics: BouncingScrollPhysics(),
                  slivers: <Widget>[
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0,vertical: 8.0),
                        child: Text("Selecciona  una category para emprezar ", style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                            fontSize: 16.0
                        ),),
                      ),
                    ),
                    SliverPadding(
                      padding: const EdgeInsets.all(16.0),
                      sliver: SliverGrid(
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              childAspectRatio: 1.2,
                              crossAxisSpacing: 10.0,
                              mainAxisSpacing: 10.0
                          ),
                          delegate: SliverChildBuilderDelegate(
                            _buildCategoryItem,
                            childCount: categories.length,

                          )

                      ),
                    ),
                  ],
                ),
              ],
            )
        );
      }

      Widget _buildCategoryItem(BuildContext context, int index) {
        Category category = categories[index];
        return MaterialButton(
          elevation: 1.0,
          highlightElevation: 1.0,
          onPressed: () => _categoryPressed(context,category),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          color: Colors.grey.shade800,
          textColor: Colors.white70,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
             if(category.icon != null)
              Icon(category.icon),
              if(category.icon != null)
                SizedBox(height: 5.0),
              Text(
               category.name,
                textAlign: TextAlign.center,
                maxLines: 3,),
            ],
          ),
        );
      }

      _categoryPressed(BuildContext context,Category category) {
        showModalBottomSheet(
          context: context,
          builder: (sheetContext) => BottomSheet(
            builder: (_) => QuizOptionsDialog(category: category,),
            onClosing: (){},

          ),

        );

      }
    }


class Category{
  final int id;
  final String name;
  final dynamic icon;
  Category(this.id, this.name, {this.icon});

}

class CheckAnswersPage extends StatelessWidget {
  //static final String path = "lib/src/pages/quiz_app/check_answers.dart";
  final List<Question> questions;
  final Map<int,dynamic> answers;

  const CheckAnswersPage({Key key, @required this.questions, @required this.answers}) : super(key: key);

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: Text('Ver Respuesta'),
        elevation: 0,
      ),
      body: Stack(
        children: <Widget>[
          ClipPath(
            clipper: WaveClipperTwo(),
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.orange,
              ),
              height: 200,
            ),
          ),
          ListView.builder(
            padding: const EdgeInsets.all(16.0),
            itemCount: questions.length+1,
            itemBuilder: _buildItem,

          )
        ],
      ),
    );
  }
  Widget _buildItem(BuildContext context, int index) {
    if(index == questions.length) {
      return RaisedButton(
        child: Text("Done"),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0)
        ),
        color: Theme.of(context).primaryColor,
        textColor: Colors.white,
        onPressed: (){
          Navigator.of(context).pushReplacement(MaterialPageRoute(
            // builder: (_) => QuizHomePage()
          ));
        },
      );
    }
    Question question = questions[index];
    bool correct = question.correctAnswer == answers[index];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(question.question, style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w500,
                fontSize: 16.0
            ),),
            SizedBox(height: 5.0),
            Text("${answers[index]}", style: TextStyle(
                color: correct ? Colors.green : Colors.red,
                fontSize: 18.0,
                fontWeight: FontWeight.bold
            ),),
            SizedBox(height: 5.0),
            correct ? Container(): Text.rich(TextSpan(
                children: [
                  TextSpan(text: "Answer: "),
                  TextSpan(text:question.correctAnswer , style: TextStyle(
                      fontWeight: FontWeight.w500
                  ))
                ]
            ),style: TextStyle(
                fontSize: 16.0
            ),)
          ],
        ),
      ),
    );
  }

  WaveClipperTwo() {}
}

enum Type {
  multiple,
  boolean
}

enum Difficulty {
  easy,
  medium,
  hard
}

class Question {
  final String categoryName;
  final Type type;
  final Difficulty difficulty;
  final String question;
  final String correctAnswer;
  final List<dynamic> incorrectAnswers;

  Question({this.categoryName, this.type, this.difficulty, this.question, this.correctAnswer, this.incorrectAnswers});

  Question.fromMap(Map<String, dynamic> data):
        categoryName = data["category"],
         type = data["type"] == "ayudas" ? Type.multiple : Type.boolean,
        difficulty = data["difficulty"] == "easy" ? Difficulty.easy : data["difficulty"] == "medium" ? Difficulty.medium : Difficulty.hard,
        question = data["question"],
        correctAnswer = data["correct_answer"],
        incorrectAnswers = data["incorrect_answers"];

    static List<Question> fromData(List<Map<String,dynamic>> data){
    return data.map((question) => Question.fromMap(question)).toList();
  }

}
class QuizPage extends StatefulWidget {
//  static final String path = "lib/src/pages/quiz_app/quiz_page.dart";
  final List<Question> questions;
  final Category category;

  const QuizPage({Key key, @required this.questions, this.category}) : super(key: key);

  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  final TextStyle _questionStyle = TextStyle(
      fontSize: 18.0,
      fontWeight: FontWeight.w500,
      color: Colors.white
  );

  int _currentIndex = 0;
  final Map<int,dynamic> _answers = {};
  final GlobalKey<ScaffoldState> _key = GlobalKey<ScaffoldState>();


  @override
  Widget build(BuildContext context){
    Question question = widget.questions[_currentIndex];
    final List<dynamic> options = question.incorrectAnswers;
    if(!options.contains(question.correctAnswer)) {
      options.add(question.correctAnswer);
      options.shuffle();
    }

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        key: _key,
        appBar: AppBar(
          backgroundColor: Colors.deepPurple,
          title: Text(widget.category.name),
          elevation: 0,
        ),
        body: Stack(
          children: <Widget>[
            ClipPath(
            // clipper: WaveClipperTwo(),
              child: Container(
                decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor
                ),
                height: 200,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      CircleAvatar(
                        backgroundColor: Colors.white70,
                        child: Text("${_currentIndex+1}"),
                      ),
                      SizedBox(width: 16.0),
                      Expanded(
                        child: Text(widget.questions[_currentIndex].question,
                          softWrap: true,
                          style: _questionStyle,),
                      ),
                    ],
                  ),

                  SizedBox(height: 20.0),
                  Card(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        ...options.map((option)=>RadioListTile(
                          title: Text("$option"),
                          groupValue: _answers[_currentIndex],
                          value: option,
                          onChanged: (value){
                            setState(() {
                              _answers[_currentIndex] = option;
                            });
                          },
                        )),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      alignment: Alignment.bottomCenter,
                      child: RaisedButton(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0)
                        ),
                        color: Theme.of(context).primaryColor,
                        textColor: Colors.white,
                        child: Text( _currentIndex == (widget.questions.length - 1) ? "Submit" : "Next"),
                        onPressed: _nextSubmit,
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  void _nextSubmit() {
    if(_answers[_currentIndex] == null) {
      _key.currentState.showSnackBar(SnackBar(
        content: Text("Elige una opcion para seguir."),
      ));
      return;
    }
    if(_currentIndex < (widget.questions.length - 1)){
      setState(() {
        _currentIndex++;
      });
    } else {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => QuizFinishedPage(questions: widget.questions, answers: _answers)
      ));
    }
  }

  Future<bool> _onWillPop() async {
    return showDialog<bool>(
        context: context,
        builder: (_) {
          return AlertDialog(
            content: Text("Estas seguro de salir?  se pierde todo el proceso."),
            title: Text("Warning!"),
            actions: <Widget>[
              FlatButton(
                child: Text("Si"),
                onPressed: (){
                  Navigator.pop(context,true);
                },
              ),
              FlatButton(
                child: Text("No"),
                onPressed: (){
                  Navigator.pop(context,false);
                },
              ),
            ],
          );
        }
    );
  }
}
const Map<int,dynamic> demoAnswers = {
  0:"ayuda por discapacidad",
  1:1,
  2:"checke bebe",
  3:"ayudas",
  4:"Marshmallow",
  5:"140",
  6:"Python",
  7:"True",
  8:"Jakarta"
};

final List<Category> categories = [
  Category(9,"Ayudas publicas Galicia", icon: Icons.help),
  Category(10,"Ayudas sociales", icon: Icons.search),
  Category(11,"Programas de apuyo", icon: Icons.settings),
  Category(12,"Buscar beca", icon: Icons.satellite),
  Category(13," Eventos Musicaless & Theatros", icon:Icons.art_track),
  Category(14,"Promciones Especiales", icon:Icons.tv),
  Category(15,"Noticia", icon: Icons.gamepad),
  Category(16,"Orientaciones sociales", icon: Icons.school),
 // Category(17,"Science & Nature", icon: Icons.departure_board),
 // Category(18,"Computer", icon:Icons.directions_railway),
  //Category(19,"Maths", icon: Icons.cake),
  Category(21,"Sports", icon: Icons.card_travel),
  Category(22,"Geography", icon:Icons.developer_mode),
  Category(23,"History", icon: Icons.donut_small),
  Category(24,"Politics"),
  Category(25,"Art", icon: Icons.ac_unit),
  Category(26,"Celebrities"),
  Category(27,"Animals", icon: Icons.headset),
  Category(28,"Vehicles", icon:Icons.grade),
  Category(29,"Comics"),
  Category(30,"Gadgets", icon: Icons.missed_video_call),

];

final List<Question> demoQuestions = Question.fromData([
  {
    "category": "Science: Computers",
    "type": "multiple",
    "difficulty": "easy",
    "question": "What does the \"MP\" stand for in MP3?",
    "correct_answer": "Moving Picture",
    "incorrect_answers": [
      "Music Player",
      "Multi Pass",
      "Micro Point"
    ]
  },
  {
    "category": "Science: Computers",
    "type": "multiple",
    "difficulty": "easy",
    "question": "What amount of bits commonly equals one byte?",
    "correct_answer": "8",
    "incorrect_answers": [
      "1",
      "2",
      "64"
    ]
  },
  {
    "category": "Science: Computers",
    "type": "multiple",
    "difficulty": "easy",
    "question": "Which computer hardware device provides an interface for all other connected devices to communicate?",
    "correct_answer": "Motherboard",
    "incorrect_answers": [
      "Central Processing Unit",
      "Hard Disk Drive",
      "Random Access Memory"
    ]
  },
  {
    "category": "Science: Computers",
    "type": "multiple",
    "difficulty": "easy",
    "question": "In web design, what does CSS stand for?",
    "correct_answer": "Cascading Style Sheet",
    "incorrect_answers": [
      "Counter Strike: Source",
      "Corrective Style Sheet",
      "Computer Style Sheet"
    ]
  },
  {
    "category": "Science: Computers",
    "type": "multiple",
    "difficulty": "easy",
    "question": "What is the code name for the mobile operating system Android 7.0?",
    "correct_answer": "Nougat",
    "incorrect_answers": [
      "Ice Cream Sandwich",
      "Jelly Bean",
      "Marshmallow"
    ]
  },
  {
    "category": "Science: Computers",
    "type": "multiple",
    "difficulty": "easy",
    "question": "On Twitter, what is the character limit for a Tweet?",
    "correct_answer": "140",
    "incorrect_answers": [
      "120",
      "160",
      "100"
    ]
  },
  {
    "category": "ayudas ",
    "type": "multiple",
    "difficulty": "easy",
    "question": "Tipo familia?",
    "correct_answer": "pareja",
    "incorrect_answers": [
      " HACER el registro ",
      "fotocopia de vad",
      " pagar dinero"
    ]
  },
  {
    "category": "Science: Computers",
    "type": "boolean",
    "difficulty": "easy",
    "question": "The Windows 7 operating system has six main editions.",
    "correct_answer": "True",
    "incorrect_answers": [
      "False"
    ]
  },
  {
    "category": "Science: Computers",
    "type": "multiple",
    "difficulty": "easy",
    "question": "Which programming language shares its name with an island in Indonesia?",
    "correct_answer": "Java",
    "incorrect_answers": [
      "Python",
      "C",
      "Jakarta"
    ]
  }
]);
class LoginOnePage extends StatelessWidget {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  Widget _buildPageContent() {
    return Container(
      padding: EdgeInsets.all(20.0),
      color: Colors.blue.shade600,
      child: ListView(
        children: <Widget>[

          Column(

            children: <Widget>[
              SizedBox(height: 50,),
              Container(width: 200, child: Image.asset('Background.jpg'),),
              SizedBox(height: 50,),
              ListTile(
                  title: TextField(
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                        hintText: "Email @:",
                        hintStyle: TextStyle(color: Colors.white70),
                        border: InputBorder.none,
                        icon: Icon(Icons.email, color: Colors.white30,)
                    ),
                  )
              ),
              Divider(color: Colors.grey.shade600,),
              ListTile(
                  title: TextField(
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                        hintText: "Password:",
                        hintStyle: TextStyle(color: Colors.white70),
                        border: InputBorder.none,
                        icon: Icon(Icons.lock, color: Colors.white30,)
                    ),
                  )
              ),
              Divider(color: Colors.grey.shade600,),
              SizedBox(height: 20,),
              Row(
                children: <Widget>[
                  Expanded(
                    child: RaisedButton(
                      onPressed: (){
                        login();
                      },
                      color: Colors.cyan,
                      child: Text('Login', style: TextStyle(color: Colors.white70, fontSize: 16.0),),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 40,),
              Text('Forgot your password?', style: TextStyle(color: Colors.grey.shade500),)
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _buildPageContent(),
      key: _formKey,
    );
  }
}

void login() {


  //final formstate = _formKey.currentState;

}

class SchoolList extends StatefulWidget {
  SchoolList({Key key}) : super(key: key);
  static final String path = "lib/src/pages/lists/list2.dart";

  _SchoolListState createState() => _SchoolListState();
}

class _SchoolListState extends State<SchoolList> {
  final TextStyle dropdownMenuItem =
  TextStyle(color: Colors.black, fontSize: 18);

  final primary = Color(0xff696b9e);
  final secondary = Color(0xfff29a94);

  final List<Map> schoolLists = [
    {
      "name": "Hakim samouh",
      "location": "572 Statan NY, 12483",
      "type": "Higher Secondary School",
      "logoText":
      "https://cdn.pixabay.com/photo/2019/07/06/20/06/drops-4321147_960_720.jpg"
    },
    {
      "name": "Xaviers International",
      "location": "234 Road Kathmandu, Nepal",
      "type": "Higher Secondary School",
      "logoText":
      "https://cdn.pixabay.com/photo/2019/07/06/20/06/drops-4321147_960_720.jpg"
    },
    {
      "name": "Kinder Garden",
      "location": "572 Statan NY, 12483",
      "type": "Play Group School",
      "logoText":
      "https://cdn.pixabay.com/photo/2013/08/28/12/03/plumage-176723_960_720.jpg"
    },
    {
      "name": "WilingTon Cambridge",
      "location": "Kasai Pantan NY, 12483",
      "type": "Lower Secondary School",
      "logoText":
      "https://cdn.pixabay.com/photo/2013/08/28/12/03/plumage-176723_960_720.jpg"
    },
    {
      "name": "Fredik Panlon",
      "location": "572 Statan NY, 12483",
      "type": "Higher Secondary School",
      "logoText":
      "https://cdn.pixabay.com/photo/2017/03/16/21/18/logo-2150297_960_720.png"
    },
    {
      "name": "Whitehouse International",
      "location": "234 Road Kathmandu, Nepal",
      "type": "Higher Secondary School",
      "logoText":
      "https://cdn.pixabay.com/photo/2017/01/31/13/14/animal-2023924_960_720.png"
    },
    {
      "name": "Haward Play",
      "location": "572 Statan NY, 12483",
      "type": "Play Group School",
      "logoText":
      "https://cdn.pixabay.com/photo/2016/06/09/18/36/logo-1446293_960_720.png"
    },
    {
      "name": "Campare Handeson",
      "location": "Kasai Pantan NY, 12483",
      "type": "Lower Secondary School",
      "logoText":
      "https://cdn.pixabay.com/photo/2017/01/13/01/22/rocket-1976107_960_720.png"
    },
  ];



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xfff0f0f0),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Stack(
            children: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 145),
                height: MediaQuery.of(context).size.height,
                width: double.infinity,
                child: ListView.builder(
                    itemCount: schoolLists.length,
                    itemBuilder: (BuildContext context, int index) {
                      return buildList(context, index);
                    }),
              ),
              Container(
                height: 140,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: primary,
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30))),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      IconButton(
                        onPressed: () {},
                        icon: Icon(
                          Icons.menu,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        "Institutes",
                        style: TextStyle(color: Colors.white, fontSize: 24),
                      ),
                      IconButton(
                        onPressed: () {},
                        icon: Icon(
                          Icons.filter_list,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      height: 110,
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Material(
                        elevation: 5.0,
                        borderRadius: BorderRadius.all(Radius.circular(30)),
                        child: TextField(

                         //controller: TextEditingController(text: location[0]),
                          cursorColor: Theme.of(context).primaryColor,
                          style: dropdownMenuItem,
                          decoration: InputDecoration(
                              hintText: "Search School",
                              hintStyle: TextStyle(
                                  color: Colors.black38, fontSize: 16),
                              prefixIcon: Material(
                                elevation: 0.0,
                                borderRadius:
                                BorderRadius.all(Radius.circular(30)),
                                child: Icon(Icons.search),
                              ),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(
                                  horizontal: 25, vertical: 13)),
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget buildList(BuildContext context, int index) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        color: Colors.white,
      ),
      width: double.infinity,
      height: 110,
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 50,
            height: 50,
            margin: EdgeInsets.only(right: 15),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(50),
              border: Border.all(width: 3, color: secondary),
              image: DecorationImage(
                  image: NetworkImage(schoolLists[index]['logoText']),
                  fit: BoxFit.fill),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  schoolLists[index]['name'],
                  style: TextStyle(
                      color: primary,
                      fontWeight: FontWeight.bold,
                      fontSize: 18),
                ),
                SizedBox(
                  height: 6,
                ),
                Row(
                  children: <Widget>[
                    Icon(
                      Icons.location_on,
                      color: secondary,
                      size: 20,
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Text(schoolLists[index]['location'],
                        style: TextStyle(
                            color: primary, fontSize: 13, letterSpacing: .3)),
                  ],
                ),
                SizedBox(
                  height: 6,
                ),
                Row(
                  children: <Widget>[
                    Icon(
                      Icons.insert_emoticon,
                      color: secondary,
                      size: 20,
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Text(schoolLists[index]['type'],
                        style: TextStyle(
                            color: primary, fontSize: 13, letterSpacing: .3)),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
class AnimationOneDetails extends StatelessWidget {
  //static final String path = "lib/src/pages/animations/animation1/details.dart";
  final int index;

  const AnimationOneDetails({Key key, this.index}) : super(key: key);

  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Hero(
              tag: "image$index",
              child: Image.asset(images[index], fit: BoxFit.cover)),
          Container(
            padding: const EdgeInsets.all(16.0),
            width: double.infinity,
            height: double.infinity,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(height: 20.0),
                IconButton(
                  color: Colors.white,
                  icon: Icon(Platform.isIOS ? Icons.arrow_back_ios : Icons.arrow_back),
                  onPressed: () => Navigator.pop(context),
                ),
                Spacer(),
                SizedBox(height: 10.0),
                Hero(
                  tag: "title$index",
                  child: Material(
                    type: MaterialType.transparency,
                    child: Text(dummy[index]["title"], style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold
                    ),),
                  ),
                ),
                SizedBox(height: 20.0),
                Hero(
                  tag: "price$index",
                  child: Material(
                    type: MaterialType.transparency,
                    child: Text(dummy[index]['price'], textAlign: TextAlign.start, style: TextStyle(
                        fontSize: 30.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.white
                    ),),
                  ),
                ),
                SizedBox(height: 20.0),
              ],
            ),
          )
        ],
      ),
    );
  }
}
const List<String> images = [
  "https://pixabay.com/es/photos/gotas-agua-roc%C3%ADo-macro-hierba-4321147/",
  "https://pixabay.com/es/photos/gotas-agua-roc%C3%ADo-macro-hierba-4321147/",
  "https://pixabay.com/es/photos/gotas-agua-roc%C3%ADo-macro-hierba-4321147/",
];

const List<Map> dummy = [
  {
    "title": "Beautiful Cardigan",
    "price": "\$600"
  },
  {
    "title": "Leather Bag",
    "price": "\$400"
  },
  {
    "title": "White Beautiful Bag",
    "price": "\$350"
  },
];

class CartOnePage extends StatelessWidget {
  static final String path = "lib/src/pages/ecommerce/cart1.dart";
  final List<Map> items = [
    {
      "image":"assets/Background.jpg",
      "title":"Tagin de carne y cuerlas ",
      "price": 20
    },
    {
      "image":"assets/grimace.png",
      "title":"Pastela de pollo ",
      "price": 30
    },

    {
      "image":"assets/grimace.png",
      "title":"Pastela de Pescado ",
      "price": 25
    },
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
                padding: EdgeInsets.symmetric(horizontal:16.0, vertical: 30.0),
                child: Text("Welcome to Mediterraneo-Food ", style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade700
                ),)),
            Expanded(child: ListView.builder(
              padding: EdgeInsets.all(16.0),
              itemCount: items.length,
              itemBuilder: (BuildContext context, int index){
                return Stack(
                  children: <Widget>[
                    Container(
                      width: double.infinity,
                      margin: EdgeInsets.only(right: 30.0, bottom: 10.0),
                      child: Material(
                        borderRadius: BorderRadius.circular(5.0),
                        elevation: 3.0,
                        child: Container(
                          padding: EdgeInsets.all(16.0),
                          child: Row(
                            children: <Widget>[
                              Container(
                                height: 80,
                                child: Image.asset(items[index]["image"]),
                              ),
                              SizedBox(width: 10.0,),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(items[index]["title"], style: TextStyle(
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.bold
                                    ),),
                                    SizedBox(height: 20.0,),
                                    Text("\$${items[index]['price']}", style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18.0
                                    ),),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 20,
                      right: 35,
                      child: Container(
                        height: 25,
                        width: 20,
                        alignment: Alignment.center,
                        child: MaterialButton(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                          padding: EdgeInsets.all(0.0),
                          color: Colors.pinkAccent,
                          child: Icon(Icons.clear, color: Colors.white,),
                          onPressed: () {},
                        ),
                      ),
                    )
                  ],
                );
              },

            ),),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text("Subtotal      50€", style: TextStyle(
                      color: Colors.grey.shade700,
                      fontSize: 16.0
                  ),),
                  SizedBox(height: 5.0,),
                  Text("Envio       05€", style: TextStyle(
                      color: Colors.grey.shade700,
                      fontSize: 16.0
                  ),),
                  SizedBox(height: 10.0,),
                  Text("Total a pagar     55€", style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18.0
                  ),),
                  SizedBox(height: 20.0,),
                  SizedBox(
                    width: double.infinity,
                    child: MaterialButton(
                      height: 50.0,
                      color: Colors.deepPurpleAccent,
                      child: Text("Realizar el pago ".toUpperCase(), style: TextStyle(
                          color: Colors.white
                      ),),
                      onPressed: (){},
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}


class GridListExample extends StatelessWidget {
  const GridListExample({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      // Create a grid with 2 columns. If you change the scrollDirection to
      // horizontal, this would produce 2 rows.
      crossAxisCount: 2,
      scrollDirection: Axis.vertical,
      // Generate 100 Widgets that display their index in the List
      children: List.generate(10, (index) {

        return Center(
          child: Container(


            decoration: BoxDecoration(
              color: Colors.amber,
              border: Border.all(color: Colors.blueGrey, width: 2.0),
              borderRadius: BorderRadius.circular(15.0),
            ),
            padding: const EdgeInsets.all(36.0),

            margin: EdgeInsets.all(12),

            child: Text(

              'Item $images',

              style: Theme.of(context).textTheme.headline,
            ),

          ),
        );
      }),
    );
  }
}