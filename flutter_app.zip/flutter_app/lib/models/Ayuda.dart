//import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';


class Ayuda {

  DateTime fecha;
  String _id;

  String get id => _id;
  String _titulo;
  String _descripcion;
  String _enlace;
  String _image;

  //constructor
  Ayuda(this._titulo, this._descripcion, this._enlace, this._image, this.fecha);

  //Mapeao
  Ayuda.map(dynamic object){
    this._titulo = object["titulo"];
    this._descripcion = object["descripcion"];
    this._enlace = object["enlace"];
    this._image = object["image"];
    this.fecha = object["fecha"];
  }

 Ayuda.fromSnapShot(DataSnapshot snapshot){
    _id = snapshot.key;
    _titulo = snapshot.value['titulo'];
    _descripcion = snapshot.value['descripcion'];
    _enlace = snapshot.value['enlace'];
    _image = snapshot.value['image'];
  }

//getters
  String get titulo => _titulo;

  String get descripcion => _descripcion;

  String get enlace => _enlace;

  String get image => _image;





}
